var searchData=
[
  ['resourcemanager',['ResourceManager',['../class_resource_manager.html',1,'']]]
];
