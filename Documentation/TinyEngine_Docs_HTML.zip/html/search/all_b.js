var searchData=
[
  ['togglemusic',['toggleMusic',['../class_s_f_x_manager.html#a4fa41e47d5c1a13084fa2c521eeef20e',1,'SFXManager::toggleMusic()'],['../class_game_engine.html#a582f63a7e83592cd6a8b2e3e5d445803',1,'GameEngine::ToggleMusic()']]]
];
